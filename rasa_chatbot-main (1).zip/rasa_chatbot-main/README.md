# Covid-19 Tracker Rasa Chatbot

A Basic Conversational Chatbot Made with COVID-19 DATA and Integrated with COVID-19 Tracker's API to get real time details of Cases from all across India.

Made using RASA Framework
RASA is an open-source framework used to Build contextual AI assistants and chatbots in text and voice with open source machine learning framework.

Output:

![rasa op1](https://user-images.githubusercontent.com/74913157/118596712-5eb28780-b7c9-11eb-9f4a-a75fb9213bda.png)


![rasa op2](https://user-images.githubusercontent.com/74913157/118596728-63773b80-b7c9-11eb-9ecc-d307a40951ea.png)
